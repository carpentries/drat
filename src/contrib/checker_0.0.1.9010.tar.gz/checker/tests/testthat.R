library(testthat)
library(checker)

test_check("checker")
