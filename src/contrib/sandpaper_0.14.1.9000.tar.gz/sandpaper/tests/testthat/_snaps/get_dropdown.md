# get_dropdown works as expected with messages [plain]

    Code
      s <- get_dropdown(res, "episodes")
    Message
      i No schedule set, using Rmd files in 'episodes/' directory.
      > To remove this message, define your schedule in 'config.yaml' or use `set_episodes()` to generate it.

