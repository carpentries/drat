# episodes missing question blocks and timings do not throw error

    Code
      res <- get_syllabus(tmp, questions = TRUE)
    Condition
      Warning:
      No section called 'questions'
      Warning:
      No section called 'questions'
      Warning:
      There are missing timings from 1 episode.
      * 'draft.md'
      i The default value of 5 minutes will be used for teaching and exercises.

