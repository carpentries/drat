# set_episodes() will display the modifications if write is not specified

    episodes:
    - 01-introduction.Rmd
    x 02-new.Rmd

