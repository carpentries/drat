library(testthat)
library(pegboard)

test_check("pegboard")
