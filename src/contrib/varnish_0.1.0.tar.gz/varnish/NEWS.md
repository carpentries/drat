# varnish 0.1.0

* Breaking change; moving from the carpentries/styles theme to the new theme
  developed in 2021. Variables and layouts have changed significantly, so this
  package gains a significant update.

# varnish 0.0.0.9008

* instructor block placeholder added

# varnish 0.0.0.9007

* update css to use em and not px
* align logo with navbar
* add testing phase notification to navbar

# varnish 0.0.0.9006

* First tracked version of varnish
* updated links to engines in the footer
