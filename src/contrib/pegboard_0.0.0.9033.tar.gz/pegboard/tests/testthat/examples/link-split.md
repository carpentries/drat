Head here for [more examples of Icebreakers][icebreakers].

Introduction materials are adapted from [Carnegie Mellon Eberly
Center Teaching Excellence & Educational Innovation][credits]

[icebreakers]: {{ page.root }}/icebreakers/ "spicebreaker"
[credits]: https://www.cmu.edu/teaching/designteach/teach/firstday.html

