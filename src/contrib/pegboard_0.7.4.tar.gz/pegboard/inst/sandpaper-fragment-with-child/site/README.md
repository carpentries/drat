This directory contains rendered lesson materials. Please do not edit files
here.  
