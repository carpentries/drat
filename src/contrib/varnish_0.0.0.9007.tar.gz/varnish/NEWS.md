# varnish 0.0.0.9007

* update css to use em and not px
* align logo with navbar
* add testing phase notification to navbar

# varnish 0.0.0.9006

* First tracked version of varnish
* updated links to engines in the footer
