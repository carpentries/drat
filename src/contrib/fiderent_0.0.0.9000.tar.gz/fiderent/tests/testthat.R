library(testthat)
library(fiderent)

test_check("fiderent")
