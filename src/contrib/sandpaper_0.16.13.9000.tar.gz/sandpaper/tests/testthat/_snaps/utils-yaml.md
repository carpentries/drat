# yaml_list() processes nested lists

    
    b:
    - a
    - b
    - c
    a:
      hello:
      - a
      - b
      - c
      jello:
        c: a
        b: b
        a: c

