---
title: basic math
---

BASIC programming can make things weird:

 - Give you $2 to tell me what INKEY$ means.
 - Give you $2 to _show_ me what INKEY$ means.
 - Give you $2 to _show_ me what `INKEY$` means.

Postfix dollars mixed with prefixed dollars can make things weird:

 - We write $2 but say 2$ verbally.
 - We write $2 but _say_ 2$ verbally.
