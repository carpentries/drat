---
title: "What have these birds been studied for? Querying science outputs with R"
---

# TABLE HERE

[KILROY](https://en.wikipedia.org/wiki/Kilroy_was_here) WAS **HERE**

stop copying me!

STOP COPYING ME!

| A column | Another column | A third column |  |  | 
| -------- | -------------- | -------------- |  |  |
| a        | a              | aaaaaaaaaaaaaa |  |  | 
| a        | aaaaaaaaaaaaaa | a              |  |  | 
|          |                |                |  |  | 
| aaaaaaaa | a              | a              |  |  | 
|          |                |                |  |  | 

| a | b | c | d |
| : | - | :: | : |
| l | n | c | r |


