library(testthat)
library(tinkr)

test_check("tinkr")
