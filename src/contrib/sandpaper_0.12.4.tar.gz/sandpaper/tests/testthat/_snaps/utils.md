# a sitemap can be generated for urls

    Code
      urls_to_sitemap(urls)
    Output
      {xml_document}
      <urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
      [1] <url>\n  <loc>https://example.com/one</loc>\n</url>
      [2] <url>\n  <loc>https://example.com/two</loc>\n</url>

