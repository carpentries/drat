---
title: "Test for links that need fixing"
---


[test link]({{ page.root}}{% link _episodes/link-liquid-markdown.md %})
[test link]({{ page.root}}{% link handout.Rmd %})
[test link](handout/index.html)
[test link](handout/)
[test link](setup/index.html)
[test link](setup/)
[test link](guide/index.html)
[test link](guide/)
[test link](discuss/index.html)
[test link](discuss/)
[test link](reference.html)
[test link](reference.html#item)
[test link](code/02-episode/Makefile)
[test link](data/something.zip)


