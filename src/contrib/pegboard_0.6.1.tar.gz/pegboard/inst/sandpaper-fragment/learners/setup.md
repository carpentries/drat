---
title: Setup
---


::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: instructor

Setup instructions live in this document. Please specify the tools and the
data sets the learner needs to have installed. If you want to hide different
setup instructions, you can use a `solution` tag.

::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

:::::::::::::::: solution

## For Windows

Use [the PuTTY terminal](http://example.com/putty)

:::::::::::::::::::::::::

:::::::::::::::: solution

## For MacOS

Use [Terminal.app](http://example.com/terminal)

:::::::::::::::::::::::::


