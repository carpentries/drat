---
layout: break
title: "Lunch"
teaching: 0
exercises: 0
break: 45
---
Over lunch, reflect on and discuss the following:
* What sort of packages might you use in Python and why would you use them?
* How would data need to be formatted to be used in Pandas data frames? Would the data you have meet these requirements?
* What limitations or problems might you run into when thinking about how to apply what we've learned to your own projects or data?
