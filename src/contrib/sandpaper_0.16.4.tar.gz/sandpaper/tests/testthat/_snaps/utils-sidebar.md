# a sidebar can be created with a specific episode and will have sequential numbers

    Code
      writeLines(sb)
    Output
      <div class="accordion accordion-flush" id="accordionFlush1">
        <div class="accordion-item">
          <div class="accordion-header" id="flush-heading1">
              <a href='index.html'>0. INDEX.MD</a>
          </div><!--/div.accordion-header-->
              
        </div><!--/div.accordion-item-->
      </div><!--/div.accordion-flush-->
      
      <div class="accordion accordion-flush" id="accordionFlush2">
        <div class="accordion-item">
          <div class="accordion-header" id="flush-heading2">
              <a href='one.html'>1. ONE.MD</a>
          </div><!--/div.accordion-header-->
              
        </div><!--/div.accordion-item-->
      </div><!--/div.accordion-flush-->
      
      <div class="accordion accordion-flush" id="accordionFlushcurrent">
        <div class="accordion-item">
          <div class="accordion-header" id="flush-headingcurrent">
            <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapsecurrent" aria-expanded="true" aria-controls="flush-collapsecurrent">
              <span class="visually-hidden">Current Chapter</span>
              <span class="current-chapter">
              <a href='two.html'>2. TWO.MD</a>
              </span>
            </button>
          </div><!--/div.accordion-header-->
              
          <div id="flush-collapsecurrent" class="accordion-collapse collapse show" aria-labelledby="flush-headingcurrent" data-bs-parent="#accordionFlushcurrent">
            <div class="accordion-body">
              <ul>
                <li><a href='#plotting'>Plotting with <strong><code>ggplot2</code></strong>
        </a></li>
      <li><a href='#building'>Building your plots iteratively</a></li>
              </ul>
            </div><!--/div.accordion-body-->
          </div><!--/div.accordion-collapse-->
              
        </div><!--/div.accordion-item-->
      </div><!--/div.accordion-flush-->
      
      <div class="accordion accordion-flush" id="accordionFlush4">
        <div class="accordion-item">
          <div class="accordion-header" id="flush-heading4">
              <a href='three.html'>3. THREE.MD</a>
          </div><!--/div.accordion-header-->
              
        </div><!--/div.accordion-item-->
      </div><!--/div.accordion-flush-->
      

