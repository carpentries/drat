---
teaching: 6
exercises: 9
---

::: questions

 - What's the point?

:::

::: objectives

 - Bake him away, toys

:::

# Markdown

::: {.challenge time=10}

How do you write markdown divs?

This [link should be transformed](../learners/Setup.md)

This [rmd link also](../episodes/01-Introduction.Rmd)

This [rmd is safe](https://example.com/01-Introduction.Rmd)

This [too](learners/Setup.md#windows-setup 'windows setup')

![link should be transformed](../episodes/fig/Setup.png){alt='alt text'}

::: solution

# Write now

just write it, silly.
:::
:::

::: instructor

This should be aside

:::

::: nothing

This should be

:::
