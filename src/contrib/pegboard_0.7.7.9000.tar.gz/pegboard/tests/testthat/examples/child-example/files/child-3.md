Hello from the first child. I am just a markdown document and I have a [working
link](../index.md)
