# keypoints learner and instructor views are identical

    Code
      writeLines(sidelinks_instructor)
    Output
      <a href="../key-points.html">Learner View</a>
      <a href="index.html">Summary and Schedule</a>
      <a href="introduction.html">1. introduction</a>
      <a href="second-episode.html">2. <em>Second</em> Episode!</a>
      <a href="../instructor/key-points.html">Key Points</a>
      <a href="../instructor/instructor-notes.html">Instructor Notes</a>
      <a href="../instructor/images.html">Extract All Images</a>
      <a href="../instructor/aio.html">See all in one page</a>

---

    Code
      writeLines(sidelinks_learner)
    Output
      <a href="instructor/key-points.html">Instructor View</a>
      <a href="index.html">Summary and Setup</a>
      <a href="introduction.html">1. introduction</a>
      <a href="second-episode.html">2. <em>Second</em> Episode!</a>
      <a href="key-points.html">Key Points</a>
      <a href="reference.html#glossary">Glossary</a>
      <a href="profiles.html">Learner Profiles</a>
      <a href="reference.html">Reference</a>
      <a href="aio.html">See all in one page</a>

