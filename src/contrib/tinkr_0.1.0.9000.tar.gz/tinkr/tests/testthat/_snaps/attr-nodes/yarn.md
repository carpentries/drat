---
title: basic curly
---

# preface {#pre-face .unnumbered}

hello

I like {xml2} but of course {tinkr} is even cooler!

Images that use pandoc style will have curlies with content that should be translated and should be protected.

![a pretty kitten](https://placekitten.com/200/300){#kitteh alt='a picture of a kitten'}

![a pretty puppy](https://placedog.net/200/300){#dog alt="a picture
of a dog"}


\[a span with attributes\]{.span-with-attributes
style='color: red;'}



