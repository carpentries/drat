`%||%`  <- function(x, y) {
    if (is.null(x)) return(y)
    x
}
